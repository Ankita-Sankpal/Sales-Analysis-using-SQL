-- Create Database
CREATE DATABASE SalesDB;
USE SalesDB;

-- Create Customers Table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Location VARCHAR(255)
);

-- Create Products Table
CREATE TABLE Products (
    ProductID INT PRIMARY KEY AUTO_INCREMENT,
    ProductName VARCHAR(255) NOT NULL,
    Category VARCHAR(255),
    Price DECIMAL(10,2) NOT NULL
);

-- Create Sales Table
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY AUTO_INCREMENT,
    CustomerID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    SaleDate DATE NOT NULL,
    TotalAmount DECIMAL(10,2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Insert Sample Data
INSERT INTO Customers (Name, Email, Location) VALUES
('John Doe', 'john@example.com', 'New York'),
('Jane Smith', 'jane@example.com', 'Los Angeles'),
('Mike Johnson', 'mike@example.com', 'Chicago');

INSERT INTO Products (ProductName, Category, Price) VALUES
('Laptop', 'Electronics', 1200.00),
('Smartphone', 'Electronics', 800.00),
('Headphones', 'Accessories', 150.00);

INSERT INTO Sales (CustomerID, ProductID, Quantity, SaleDate, TotalAmount) VALUES
(1, 1, 2, '2024-01-10', 2400.00),
(2, 2, 1, '2024-02-15', 800.00),
(3, 3, 3, '2024-03-05', 450.00);

-- Queries for Analysis

-- Total Sales Revenue
SELECT SUM(TotalAmount) AS TotalRevenue FROM Sales;

-- Best-Selling Products
SELECT p.ProductName, SUM(s.Quantity) AS TotalSold
FROM Sales s
JOIN Products p ON s.ProductID = p.ProductID
GROUP BY p.ProductName
ORDER BY TotalSold DESC;

-- Sales per Customer
SELECT c.Name, SUM(s.TotalAmount) AS CustomerSpend
FROM Sales s
JOIN Customers c ON s.CustomerID = c.CustomerID
GROUP BY c.Name
ORDER BY CustomerSpend DESC;

-- Sales Trend by Month
SELECT MONTH(SaleDate) AS Month, SUM(TotalAmount) AS MonthlyRevenue
FROM Sales
GROUP BY Month
ORDER BY Month;
